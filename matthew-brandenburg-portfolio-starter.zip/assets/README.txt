Place profile.jpg, cover.jpg, favicon.png here.
Place PDF resume as Matthew_Brandenburg_Resume.pdf
